import {Auth} from "../../auth";
import host from "../../config/config";
import {CategoriesResponseType} from "../../types/categories-response.type";
import {DefaultResponseType} from "../../types/default-response.type";
import {RefreshResponseType} from "../../types/refresh-response.type";

export class ExpensesCreate {
    readonly openNewRoute: Function;
    readonly token: string | null;
    readonly refreshToken: string | null;
    readonly categoryTextElement: HTMLElement | null = document.getElementById('expense-create-input');
    readonly categoryExpenseCreateElement: HTMLElement | null = document.getElementById('expense-create');
    readonly categoryExpenseCancelCreateElement: HTMLElement | null = document.getElementById('expense-create-cancel');

    readonly errorElement: HTMLElement | null = document.querySelector('.error-message');
    constructor(openNewRoute:Function) {
        this.openNewRoute = openNewRoute;
        this.token = localStorage.getItem(Auth.accessTokenKey);
        this.refreshToken = localStorage.getItem(Auth.refreshTokenKey);
        if (!this.token || !this.refreshToken) {
            return this.openNewRoute('/login');
        }
        if (this.categoryExpenseCreateElement) {
            this.categoryExpenseCreateElement.addEventListener('click', this.createExpense.bind(this));
        }
        if(this.categoryExpenseCancelCreateElement) {
            this.categoryExpenseCancelCreateElement.addEventListener('click', this.notCreate.bind(this));
        }
    }
    private async createExpense(e:MouseEvent): Promise<Response | undefined> {
        e.preventDefault();

        if (this.errorElement && this.categoryTextElement && (this.categoryTextElement as HTMLInputElement).value) {
            this.errorElement.style.display = 'none';
            this.categoryTextElement.classList.add('mb-4');
            this.errorElement.style.color = '';
            this.errorElement.style.marginBottom = '';

            const categoryData = {
                title: (this.categoryTextElement as HTMLInputElement).value
            }
            const params: RequestInit = {
                method: 'POST',
                headers: {
                    'Content-type': 'application/json',
                    'Accept': 'application/json',
                    'x-auth-token': this.token ?? '',
                },
                body: JSON.stringify(categoryData)
            }
            const response: Response = await fetch(host + 'categories/expense', params);
            const result: CategoriesResponseType | DefaultResponseType | RefreshResponseType = await response.json();
            if (!result || (result as DefaultResponseType).error) {
                if (response.status === 401) {
                    const updateTokenResult = await fetch(host + 'refresh', {
                        method: 'POST',
                        headers: {
                            'Content-type': 'application/json',
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify({refreshToken: this.refreshToken})
                    });

                    if (updateTokenResult.status === 200) {
                        const tokens = await updateTokenResult.json();


                        if (tokens && !tokens.error) {
                            Auth.setTokens(tokens.tokens.accessToken, tokens.tokens.refreshToken);
                            return response;
                        }
                    } else {
                        Auth.removeTokens();
                        localStorage.removeItem(Auth.userInfoKey);
                        this.openNewRoute('/login');
                    }
                }
            }
            return this.openNewRoute('/expenses');
        } else {
            if (this.categoryTextElement && this.errorElement) {
                this.categoryTextElement.classList.remove('mb-4');
                this.errorElement.style.color = 'red';
                this.errorElement.style.marginBottom = '10px';
                this.errorElement.style.display = 'block';
            }
        }
    }

    private notCreate(e:MouseEvent): void {
        e.preventDefault();
        this.openNewRoute('/expenses');
    }

}