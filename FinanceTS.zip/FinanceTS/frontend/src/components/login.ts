import {Auth} from "../auth";
import host from "../config/config";
import {DefaultResponseType} from "../types/default-response.type";
import {RefreshResponseType} from "../types/refresh-response.type";
import {LoginResponseType} from "../types/login-response.type";
export class Login {
    readonly openNewRoute: (arg0: string) => void;
    readonly emailElement: HTMLElement | null = document.getElementById('email');
    readonly passwordElement: HTMLElement | null = document.getElementById('password');
    readonly formElement: HTMLElement | null = document.getElementById('form');
    readonly rememberMeElement: HTMLElement | null = document.getElementById('remember-me');
    readonly commonErrorElement: HTMLElement | null = document.getElementById('common-error');
    readonly processButtonElement: HTMLElement | null = document.getElementById('process-button');
    constructor(openNewRoute: (arg0: string) => void) {
        this.openNewRoute = openNewRoute;
        if (localStorage.getItem(Auth.accessTokenKey)) {
            this.openNewRoute('/');
        }
        if (this.processButtonElement)  {
            this.processButtonElement.addEventListener('click', this.login.bind(this));
        }
    }

    private validateForm(): boolean {
        let isValid: boolean = true;
        if (this.formElement && this.passwordElement && this.emailElement) {
        if (this.formElement && this.emailElement && (this.emailElement as HTMLInputElement).value && (this.emailElement as HTMLInputElement).value.match(/^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/)) {
            this.formElement.classList.remove('was-validated');
            this.emailElement.classList.remove('is-invalid');
        } else {
            this.formElement.classList.add('was-validated');
            this.emailElement.classList.add('is-invalid');
            isValid = false;
        }

            if ((this.passwordElement as HTMLInputElement).value) {
                this.formElement.classList.remove('was-validated');
                this.passwordElement.classList.remove('is-invalid');
            } else {
                this.formElement.classList.add('was-validated');
                this.passwordElement.classList.add('is-invalid');
                isValid = false;
            }
        }
        return isValid;
    }

    private async login(): Promise<void>  {
        if (this.commonErrorElement) {
            this.commonErrorElement.style.display = 'none';
        }
        if (this.validateForm()) {
            const response: Response = await fetch(host + 'login', {
                method: 'POST',
                headers: {
                    'Content-type': 'application/json',
                    'Accept': 'application/json',
                },
                body: JSON.stringify({
                    email: (this.emailElement as HTMLInputElement).value,
                    password: (this.passwordElement as HTMLInputElement).value,
                    rememberMe: (this.rememberMeElement as HTMLInputElement).checked
                })
            });
            const result:LoginResponseType | DefaultResponseType = await response.json();
            if ((result as DefaultResponseType).error || !(result as LoginResponseType).tokens.accessToken || !(result as LoginResponseType).tokens.refreshToken || !(result as LoginResponseType).user.name || !(result as LoginResponseType).user.lastName || !(result as LoginResponseType).user.id) {
                if (response.status === 401) {
                   const refreshToken = localStorage.getItem(Auth.refreshTokenKey);
                    if(refreshToken) {
                        const request = await fetch(host + 'refresh', {
                            method: 'POST',
                            headers: {
                                'Content-type': 'application/json',
                                'Accept': 'application/json',
                            },
                            body: JSON.stringify({refreshToken: refreshToken})
                        });
                        if (request && request.status === 200) {
                            const result: RefreshResponseType |DefaultResponseType = await request.json();
                            if (result && !(result as DefaultResponseType).error) {
                                Auth.setTokens((result as RefreshResponseType).tokens.accessToken, (result as RefreshResponseType).tokens.refreshToken);
                                return;
                            }
                        }
                    }
                    Auth.removeTokens();
                    this.openNewRoute('/login');
                    return;
                }
                if (this.commonErrorElement) {
                    this.commonErrorElement.style.display = 'block';
                }
            }
            Auth.removeTokens();
            if ((result as RefreshResponseType).tokens.accessToken && (result as RefreshResponseType).tokens.refreshToken) {
                Auth.setTokens((result as RefreshResponseType).tokens.accessToken, (result as RefreshResponseType).tokens.refreshToken);
            }
            localStorage.setItem(Auth.userInfoKey, JSON.stringify({
                name: (result as LoginResponseType).user.name,
                lastName: (result as LoginResponseType).user.lastName,
                id: (result as LoginResponseType).user.id
            }));
            this.openNewRoute('/');
            return;
        }
        this.openNewRoute('/login');
        return;
    }
}