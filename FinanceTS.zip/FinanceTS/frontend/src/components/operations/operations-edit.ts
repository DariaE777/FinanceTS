import {Auth} from "../../auth";
import host from "../../config/config";
import {DefaultResponseType} from "../../types/default-response.type";
import {GetOperationsDataType, GetOperationsResponseType} from "../../types/get-operations-response.type";
import {CategoriesResponseType} from "../../types/categories-response.type";

export class OperationsEdit {
    readonly openNewRoute: Function;
    readonly token: string | null;
    readonly refreshToken: string | null;
    readonly operationEditTitle: HTMLElement | null = document.getElementById('operation-edit-title');
    readonly typeElement: HTMLElement | null = document.getElementById('type-edit-input');
    readonly categoryInputElement: HTMLElement | null = document.getElementById('category-edit-input');
    readonly categoryOptionElement: HTMLElement | null = document.getElementById('category-edit-option');
    readonly sumElement: HTMLElement | null = document.getElementById('sum-edit-input');
    readonly dateElement: HTMLElement | null = document.getElementById('date-edit-input');
    readonly commentElement: HTMLElement | null = document.getElementById('comment-edit-input');
    readonly operationUpdateElement: HTMLElement | null = document.getElementById('operation-update');
    readonly operationUpdateCancelElement: HTMLElement | null = document.getElementById('operation-update-cancel');
    private originalOperationData: GetOperationsDataType| GetOperationsResponseType | null = null;
    private categoryArray: CategoriesResponseType[] | null = null;
    readonly id: number | null = null;
    constructor(openNewRoute:Function) {
        this.openNewRoute = openNewRoute;
        this.token = localStorage.getItem(Auth.accessTokenKey);
        this.refreshToken = localStorage.getItem(Auth.refreshTokenKey);
        if (!this.token || !this.refreshToken) {
            return this.openNewRoute('/login');
        }
        if(this.operationUpdateElement) {
            this.operationUpdateElement.addEventListener('click', this.updateCategoryOperations.bind(this));
        }
       if (this.operationUpdateCancelElement) {
            this.operationUpdateCancelElement.addEventListener('click', this.updateCancel.bind(this));
        }

        const urlParams: URLSearchParams = new URLSearchParams(window.location.search);
       const urlId:string | null = urlParams.get('id');
       if(urlId) {
           this.id = parseInt(urlId) ;
           if (!this.id) {
               return this.openNewRoute('/');
           }
           this.getOperation().then();
       }
    }
    private async getOperation(): Promise<Response | undefined> {
        const params: RequestInit = {
            method: 'GET',
            headers: {
                'Content-type': 'application/json',
                'Accept': 'application/json',
                'x-auth-token': this.token ?? '',
            }
        };
        const response: Response = await fetch(host + 'operations/' + this.id, params);
        const result: GetOperationsResponseType | DefaultResponseType = await response.json();
        if (!result || (result as DefaultResponseType).error) {
            if (response.status === 401) {
                const updateTokenResult = await fetch(host + 'refresh', {
                    method: 'POST',
                    headers: {
                        'Content-type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({refreshToken: this.refreshToken})
                });
                if (updateTokenResult && updateTokenResult.status === 200) {
                    const tokens = await updateTokenResult.json();
                    if (tokens && !tokens.error) {
                        Auth.setTokens(tokens.tokens.accessToken, tokens.tokens.refreshToken);
                        return response;
                    }
                } else {
                    Auth.removeTokens();
                    localStorage.removeItem(Auth.userInfoKey);
                    this.openNewRoute('/login');
                }
            }

        }
        if (this.originalOperationData) {
            this.originalOperationData = result as GetOperationsResponseType;
        }
        this.showOperation(result as GetOperationsResponseType);
    }
    private showOperation(operation: GetOperationsResponseType): void {
        if (this.operationEditTitle && this.typeElement && this.categoryOptionElement && this.sumElement && this.dateElement
        && this.commentElement) {
            if (operation.type === 'income') {
                this.operationEditTitle.innerText = 'Редактирование дохода';
                (this.typeElement as HTMLInputElement).placeholder = 'Доход';
            } else if (operation.type === 'expense') {
                this.operationEditTitle.innerText = 'Редактирование расхода';
                (this.typeElement as HTMLInputElement).placeholder = 'Расход';
            } else {
                throw new Error(`Invalid type: ${operation.type}`);
            }
            this.categoryOptionElement.innerText = operation.category;
            (this.sumElement as HTMLInputElement).value = operation.amount.toString();
            (this.dateElement as HTMLInputElement).value = operation.date;
            (this.commentElement as HTMLInputElement).value = operation.comment;
            this.showCategoryOptions(operation.type).then();
        }
    }
    async showCategoryOptions(type:string): Promise<Response | undefined> {
        let response: Response | null = null;
        const params: RequestInit = {
            method: 'GET',
            headers: {
                'Content-type': 'application/json',
                'Accept': 'application/json',
                'x-auth-token': this.token ?? '',
            }
        };
        if (type === 'income') {
            response = await fetch(host + 'categories/income', params);
        } else if (type === 'expense') {
            response = await fetch(host + 'categories/expense', params);
        }
        if (response) {
            const result: CategoriesResponseType[] | DefaultResponseType = await response.json();
            if (!result || (result as DefaultResponseType).error) {
                if (response.status === 401) {
                    const updateTokenResult = await fetch(host + 'refresh', {
                        method: 'POST',
                        headers: {
                            'Content-type': 'application/json',
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify({refreshToken: this.refreshToken})
                    });
                    if (updateTokenResult && updateTokenResult.status === 200) {
                        const tokens = await updateTokenResult.json();
                        if (tokens && !tokens.error) {
                            Auth.setTokens(tokens.tokens.accessToken, tokens.tokens.refreshToken);
                            return response;
                        }
                    } else {
                        Auth.removeTokens();
                        localStorage.removeItem(Auth.userInfoKey);
                        this.openNewRoute('/login');
                    }
                }
            }
            this.categoryArray = result as CategoriesResponseType[];
            for (let i = 0; i < (result as CategoriesResponseType[]).length; i++) {
                const optionElement:HTMLElement = document.createElement('option');
                if(this.categoryOptionElement && this.categoryInputElement) {
                    if (this.categoryOptionElement.innerText !== (result as CategoriesResponseType[])[i].title) {
                        optionElement.innerText = (result as CategoriesResponseType[])[i].title;
                        this.categoryInputElement.appendChild(optionElement);
                    }
                }
            }
        }

    }
    private async updateCategoryOperations(e:any): Promise<Response | undefined> {
        e.preventDefault();
        const changedData:any = {};
        if (this.originalOperationData) {
            if (parseInt((this.sumElement as HTMLInputElement).value) !== parseInt(String(this.originalOperationData.amount))) {
                (changedData as GetOperationsResponseType).amount = parseInt((this.sumElement as HTMLInputElement).value);
            }
            if ((this.dateElement as HTMLInputElement).value !== this.originalOperationData.date) {
                (changedData as GetOperationsResponseType).date = (this.dateElement as HTMLInputElement).value;
            }
            if ((this.commentElement as HTMLInputElement).value !== this.originalOperationData.comment) {
                (changedData as GetOperationsResponseType).comment = (this.commentElement as HTMLInputElement).value;
            }
            if ((this.categoryInputElement as HTMLInputElement).value !== this.originalOperationData.category) {
                (this.categoryArray as CategoriesResponseType[]).forEach((item) => {
                    if ((this.categoryInputElement as HTMLInputElement).value === item.title) {
                        return (changedData).category_id = item.id;
                    }
                })
            } else {
                (this.categoryArray as CategoriesResponseType[]).forEach(item => {
                    if ((this.categoryInputElement as HTMLInputElement).value === item.title) {
                        return (this.originalOperationData as GetOperationsDataType).category_id = item.id;
                    }
                })
            }
        }

        if (Object.keys(changedData).length > 0 && this.originalOperationData) {
            const params: RequestInit = {
                method: 'PUT',
                headers: {
                    'Content-type': 'application/json',
                    'Accept': 'application/json',
                    'x-auth-token': this.token ?? '',
                },
                body: JSON.stringify({
                    type: this.originalOperationData.type,
                    amount: changedData.amount ? changedData.amount : this.originalOperationData.amount,
                    date: changedData.date ? changedData.date : this.originalOperationData.date,
                    comment: changedData.comment ? changedData.comment : this.originalOperationData.comment,
                    category_id: changedData.category_id ? changedData.category_id : (this.originalOperationData as GetOperationsDataType).category_id
                })
            };
            const response: Response = await fetch(host + 'operations/' + this.id, params);
            const result: GetOperationsResponseType | DefaultResponseType = await response.json();
            if (!result || (result as DefaultResponseType).error) {
                if (response.status === 401) {
                    const updateTokenResult = await fetch(host + 'refresh', {
                        method: 'POST',
                        headers: {
                            'Content-type': 'application/json',
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify({refreshToken: this.refreshToken})
                    });
                    if (updateTokenResult && updateTokenResult.status === 200) {
                        const tokens = await updateTokenResult.json();
                        if (tokens && !tokens.error) {
                            Auth.setTokens(tokens.tokens.accessToken, tokens.tokens.refreshToken);
                            return response;
                        }
                    } else {
                        Auth.removeTokens();
                        localStorage.removeItem(Auth.userInfoKey);
                        this.openNewRoute('/login');
                    }
                }
                this.openNewRoute('/login');
            }
            this.openNewRoute('/operations');
        }
    }
    private updateCancel(e:MouseEvent): void {
        e.preventDefault();
        this.openNewRoute('/operations');
    }
}