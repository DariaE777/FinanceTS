import {MainPage} from "./components/mainpage";
import {SignUp} from "./components/sign-up";
import {Login} from "./components/login";
import {Income} from "./components/income/income";
import {Expenses} from "./components/expenses/expenses";
import {Operations} from "./components/operations/operations";
import {Logout} from "./components/logout";
import {Auth} from "./auth";
import {IncomeCreate} from "./components/income/income-create";
import {IncomeEdit} from "./components/income/income-edit";
import {IncomeDelete} from "./components/income/income-delete";
import {ExpensesCreate} from "./components/expenses/expenses-create";
import {ExpensesEdit} from "./components/expenses/expenses-edit";
import {ExpensesDelete} from "./components/expenses/expenses-delete";
import {OperationsCreate} from "./components/operations/operations-create";
import {OperationsEdit} from "./components/operations/operations-edit";
import {OperationsDelete} from "./components/operations/operations-delete";
import host from "./config/config";
import {RouteType} from "./types/route.type";
import {BalanceResponseType} from "./types/balance-response.type";
import {RefreshResponseType} from "./types/refresh-response.type";
import {UserInfoType} from "./types/user-info.type";
import {ParamsType} from "./types/params.type";
import {DefaultResponseType} from "./types/default-response.type";

export class Router {
    readonly titlePageElement: HTMLElement | null;
    readonly contentPageElement: HTMLElement | null;
    readonly balanceElement: HTMLElement | null;
    private userName: string | null;
    private userLastName: string | null;
    readonly profileNameElement: HTMLElement | null;
    readonly token: string | null;
    private routes: RouteType[];

    constructor() {
        this.titlePageElement = document.getElementById('title');
        this.contentPageElement = document.getElementById('content');
        this.balanceElement = document.getElementById('balance');
        this.userName = null;
        this.userLastName = null;
        this.profileNameElement = document.getElementById('profile-name');
        this.token = localStorage.getItem(Auth.accessTokenKey);
        this.initEvents();
        this.routes = [
            {
                route: '/',
                title: 'Главная',
                filePathTemplate: '/templates/main.html',
                useLayout: '/templates/layout.html',
                load: () => {
                    new MainPage(this.openNewRoute.bind(this));
                }
            },
            {
                route: '/sign-up',
                title: 'Регистрация',
                filePathTemplate: '/templates/sign-up.html',
                load: () => {
                    new SignUp(this.openNewRoute.bind(this));
                }
            },
            {
                route: '/login',
                title: 'Авторизация',
                filePathTemplate: '/templates/main.html',
                load: () => {
                    new Login(this.openNewRoute.bind(this));
                }
            },
            {
                route: '/logout',
                load: () => {
                    new Logout(this.openNewRoute.bind(this));
                }
            },
            {
                route: '/income',
                title: 'Доходы',
                filePathTemplate: '/templates/income/income.html',
                useLayout: '/templates/layout.html',
                load: () => {
                    new Income(this.openNewRoute.bind(this));
                }
            },
            {
                route: '/income/create',
                title: 'Создание категории доходов',
                filePathTemplate: '/templates/income/income-create.html',
                useLayout: '/templates/layout.html',
                load: () => {
                    new IncomeCreate(this.openNewRoute.bind(this));
                }
            },
            {
                route: '/income/edit',
                title: 'Редактирование категории доходов',
                filePathTemplate: '/templates/income/income-edit.html',
                useLayout: '/templates/layout.html',
                load: () => {
                    new IncomeEdit(this.openNewRoute.bind(this));
                }
            },
            {
                route: '/income/delete',
                load: () => {
                    new IncomeDelete(this.openNewRoute.bind(this));
                }
            },
            {
                route: '/expenses',
                title: 'Расходы',
                filePathTemplate: '/templates/expenses/expenses.html',
                useLayout: '/templates/layout.html',
                load: () => {
                    new Expenses(this.openNewRoute.bind(this));
                }
            },
            {
                route: '/expenses/create',
                title: 'Создание категории расходов',
                filePathTemplate: '/templates/expenses/expenses-create.html',
                useLayout: '/templates/layout.html',
                load: () => {
                    new ExpensesCreate(this.openNewRoute.bind(this));
                }
            },
            {
                route: '/expenses/edit',
                title: 'Редактирование категории расходов',
                filePathTemplate: '/templates/expenses/expenses-edit.html',
                useLayout: '/templates/layout.html',
                load: () => {
                    new ExpensesEdit(this.openNewRoute.bind(this));
                }
            },
            {
                route: '/expenses/delete',
                load: () => {
                    new ExpensesDelete(this.openNewRoute.bind(this));
                }
            },
            {
                route: '/operations',
                title: 'Все операции',
                filePathTemplate: '/templates/operations/operations.html',
                useLayout: '/templates/layout.html',
                load: () => {
                    new Operations(this.openNewRoute.bind(this));
                }
            },
            {
                route: '/operations/create',
                title: 'Создание дохода/расхода',
                filePathTemplate: '/templates/operations/operations-create.html',
                useLayout: '/templates/layout.html',
                load: () => {
                    new OperationsCreate(this.openNewRoute.bind(this));
                }
            },
            {
                route: '/operations/edit',
                title: 'Редактирование дохода/расхода',
                filePathTemplate: '/templates/operations/operations-edit.html',
                useLayout: '/templates/layout.html',
                load: () => {
                    new OperationsEdit(this.openNewRoute.bind(this));
                }
            },
            {
                route: '/operations/delete',
                load: () => {
                    new OperationsDelete(this.openNewRoute.bind(this));
                }
            }
        ];
    }

    public async openNewRoute(url: string): Promise<void> {
        history.pushState({}, '', url);
        await this.activateRoute();
    }

    private initEvents(): void {
        window.addEventListener('DOMContentLoaded', this.activateRoute.bind(this));
        window.addEventListener('popstate', this.activateRoute.bind(this));
        document.addEventListener('click', this.clickHandler.bind(this));
    }

    private async clickHandler(e: MouseEvent): Promise<void> {
        let element: HTMLLinkElement | null = null;
        if (e.target instanceof HTMLLinkElement) {
            if (e.target.nodeName === 'A') {
                element = e.target;
            } else if (e.target.parentNode instanceof HTMLLinkElement && e.target.parentNode.nodeName === 'A') {
                element = e.target.parentNode;
            }
        }
        if (element) {
            e.preventDefault();
            const url: string = element.href.replace(window.location.origin, '');
            if (!url || url === '/#' || url.startsWith("javascript:void(0)")) {
                return;
            }
            await this.openNewRoute(url);
        }
    }

    public async activateRoute(): Promise<Response | undefined> {
        const urlRoute: string = window.location.pathname;
        const newRoute: RouteType | undefined = this.routes.find(item => {
            return item.route === urlRoute;
        });

        if (newRoute) {
            if (newRoute.title && this.titlePageElement) {
                this.titlePageElement.innerText = newRoute.title;
            }
            if (newRoute.filePathTemplate) {
                let contentBlock: HTMLElement | null = this.contentPageElement;
                if (newRoute.useLayout) {
                    contentBlock = document.getElementById('content-layout');
                    if (this.contentPageElement) {
                        this.contentPageElement.innerHTML = await fetch(newRoute.useLayout as string).then(response => response.text());
                        const params: ParamsType = {
                            method: 'GET',
                            headers: {
                                'Content-type': 'application/json',
                                'Accept': 'application/json',
                                'x-auth-token': this.token
                            }
                        };
                        const response: Response = await fetch(host + 'balance', params as RequestInit);
                        const result: BalanceResponseType | null = await response.json();
                        if (!result) {
                            if (response.status === 401) {
                                const updateTokenResult: Response = await fetch(host + 'refresh', {
                                    method: 'POST',
                                    headers: {
                                        'Content-type': 'application/json',
                                        'Accept': 'application/json'
                                    },
                                    body: JSON.stringify({refreshToken: localStorage.getItem(Auth.refreshTokenKey)})
                                });
                                if (updateTokenResult && updateTokenResult.status === 200) {
                                    const tokens: RefreshResponseType | DefaultResponseType = await updateTokenResult.json();
                                    if (tokens && !(tokens as DefaultResponseType).error && (tokens as RefreshResponseType).tokens.accessToken && (tokens as RefreshResponseType).tokens.refreshToken) {
                                        Auth.setTokens((tokens as RefreshResponseType).tokens.accessToken, (tokens as RefreshResponseType).tokens.refreshToken);
                                        return response;
                                    }
                                } else {
                                    Auth.removeTokens();
                                    localStorage.removeItem(Auth.userInfoKey);
                                    await this.openNewRoute('/login');
                                }
                            }
                        }

                        if (this.balanceElement && result) {
                            this.balanceElement.innerText = result.balance + '$';
                        }

                        const userInfoKey: string | null = localStorage.getItem(Auth.userInfoKey);
                        if (userInfoKey) {
                            const userInfo: UserInfoType = JSON.parse(userInfoKey);
                            if (userInfo.name && userInfo.lastName) {
                                this.userName = userInfo.name;
                                this.userLastName = userInfo.lastName;
                            }
                        }
                        if (this.profileNameElement) {
                            this.profileNameElement.innerText = this.userName + ' ' + this.userLastName + ' ';
                        }
                        this.activateMenuItem(newRoute);
                    }
                }
                if (contentBlock) {
                    contentBlock.innerHTML = await fetch(newRoute.filePathTemplate).then(response => response.text());
                }
            }
            if (newRoute.load && typeof newRoute.load === 'function') {
                newRoute.load();
            }
        } else {
            history.pushState({}, '', '/login');
            await this.activateRoute();
        }
    }

    private activateMenuItem(route: RouteType): void {
        document.querySelectorAll('.sidebar .nav-link').forEach(item => {
            const href: string | null = item.getAttribute('href');
            if (!href) {
                return;
            }
            if ((route.route.includes(href) && href !== '/') || (route.route === '/' && href === '/')) {
                item.classList.add('active');
            } else {
                item.classList.remove('active');
            }
        });
    }
}