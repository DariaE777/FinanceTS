export type OptionsType = {
    responsive: boolean,
        plugins: {
    legend: {
        display: boolean,
            labels: {
            color: string,
                font: {
                size: number
            }
        }
    },
}
}