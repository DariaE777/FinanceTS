import {Chart, ChartType, LegendElement, LegendOptions} from "chart.js";

export type MarginPluginType = {
    id: string,
    beforeInit(chart: Chart<ChartType>, legend: LegendElement<ChartType>, options: LegendOptions<ChartType>): void;
}
