export type UserInfoType = {
    id: number,
    email: string,
    name: string,
    lastName: string
}