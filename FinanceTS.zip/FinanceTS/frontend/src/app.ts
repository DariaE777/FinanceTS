
import "./styles/style-layout.scss";
import "./styles/common.scss";

import {Router} from "./router";

class App {
    private router: Router;
    constructor() {
        this.router = new Router();
        window.addEventListener('DOMContentLoaded', this.handleRouteChanging.bind(this));
    }
    private handleRouteChanging():void {
        this.router.activateRoute().then();
    }
}

(new App());